# SmolBit

SmolBit is a programming language i've been making for a little while. This is a python package specifically made for compiling and running it.

To use the package, simply install it (`pip install SmolBit`) and run `python -m SmolBit` with any additional arguments needed.